// All site content extracted from original site
export const SITE = {
  brand: 'DJ Stephen',
  logo: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/4rjcm7mi_DJ%20Stephen.png.PNG',
  phone: '(587) 201-9664',
  phoneTel: 'tel:5872019664',
  instagram: 'https://www.instagram.com/djstephenyyc',
  instagramHandle: '@djstephenyyc',
  location: 'Calgary, AB, Canada',
  serviceArea: 'Calgary & Area',
  tagline: 'Professional DJ services for all events in Calgary, Alberta.',
  email: '',
};

export const HERO = {
  image: '/assets/dj-stephen-hero.jpg',
  kicker: "Calgary's Premier DJ",
  titleStart: "Hey, I'm ",
  titleAccent: 'DJ Stephen',
  p1: "With a passion for music and a commitment to excellence, I bring premium sound quality and unmatched energy to every event. Whether it's an intimate wedding reception or a high-energy corporate celebration, every performance is tailored to create unforgettable memories.",
  p2: 'From carefully curated setlists to state-of-the-art equipment, my attention to detail ensures your event sounds as amazing as it looks.',
};

export const SPECIALTIES = [
  { icon: 'Heart', title: 'Weddings', desc: 'Make your special day unforgettable', color: 'rose' },
  { icon: 'Cake', title: 'Birthday Parties', desc: 'High-energy celebrations for all ages', color: 'amber' },
  { icon: 'GraduationCap', title: 'Grad Parties', desc: 'Celebrate milestones in style', color: 'violet' },
  { icon: 'Building2', title: 'Corporate Events', desc: 'Professional entertainment', color: 'cyan' },
  { icon: 'Music', title: 'Club Events', desc: 'Nightclub experience anywhere', color: 'fuchsia' },
  { icon: 'PartyPopper', title: 'Private Events', desc: 'Custom DJ for any occasion', color: 'emerald' },
];

export const PACKAGES = [
  {
    name: 'Low Budget & Special Party',
    tagline: 'Ideal for House Parties, Kids Parties, & Outdoor Parties',
    price: '$450',
    priceNote: 'starting',
    badge: 'Budget Friendly',
    badgeStyle: 'pink',
    accent: 'pink',
    features: [
      'Up to 50 guests',
      '4-5 hours of music',
      'Basic sound system',
      'Custom playlist',
    ],
    cta: 'outline',
  },
  {
    name: 'Small Party',
    tagline: 'Perfect for intimate gatherings',
    price: '$750',
    priceNote: 'starting',
    features: [
      'Up to 70-90 guests',
      '4-5 hours of music',
      'Professional sound system',
      'Basic lighting setup',
      'Custom playlist curation',
    ],
    cta: 'outline',
  },
  {
    name: 'Standard Event',
    tagline: 'Ideal for birthday parties & celebrations',
    price: '$1,100',
    priceNote: 'starting',
    badge: 'Popular',
    badgeStyle: 'cyan',
    accent: 'cyan',
    features: [
      'Up to 100 guests',
      '5 hours of music',
      'Premium sound system',
      'LED lighting package',
      'Song Requests & Custom Playlist',
      'Custom playlist curation',
    ],
    cta: 'solid',
  },
  {
    name: 'Premium Wedding',
    tagline: 'Full-service wedding DJ experience',
    price: 'Custom',
    isCustom: true,
    features: [
      'Unlimited guests',
      'Full day coverage',
      'Top-tier sound system',
      'Complete lighting design',
      'MC & coordination',
      'Ceremony + reception music',
      'Consultation included',
    ],
    cta: 'outline',
  },
];

export const VIDEOS = [
  { title: 'DJ Stephen with Friends', src: 'https://customer-assets.emergentagent.com/job_legacy-intact/artifacts/wdg4z0et_copy_812873C2-3CF2-4BF1-AFB7-80F49E69919A.mov' },
  { title: 'Live Party Reaction & Stephen', src: 'https://customer-assets.emergentagent.com/job_legacy-intact/artifacts/opw7w4d6_copy_7114A8FE-79DA-4573-89CA-AEBF1D6EC41A.MOV' },
  { title: 'RYP & DJ Stephen', src: 'https://customer-assets.emergentagent.com/job_legacy-intact/artifacts/64zqmash_IMG_5585%202.MOV' },
  { title: 'Dynasty Power Christmas Party 2024', src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/2vn8dwtz_ssstwitter.com_1734365135846.MP4' },
  { title: 'DJ Stephen Afrobeat Party', src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/68sdgunu_ssstwitter.com_1741494115443.MP4' },
  { title: 'Latin Wedding 2025', src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/5tu36fp7_AQPoO7QnlH8qt-Sq1883E9xSn6WSnoB_gUcpnmIhJNRZ-5B10_9A_8jTCb8MWWgKKekse9w65teziBP3GrA0SgjH.mp4' },
  { title: 'Full Wedding Setup', src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/9rnnjwjk_AQONGuYOa4XguIOezt6qo3HbWWEanS1pZeoBrnKRLaN2DJsZv7xbK6FO4L1tOpuOvDmNqX9uoWC435R2m1u5rUI3.mov' },
  { title: 'Reception Dinner Party', src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/ci5bhldu_IMG_3210.mov' },
  { title: 'Reception Party - Birthday', src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/t0mge6k2_AQMM5LRk-0x-xSOg9qOvzh3sz9XD_h4aYGDvbHSZQfXSYhVtPQwabQJqtRnUPJ9x7ZOSQ1HT46bTOZBuMd3G9e2C.MP4' },
  { title: '40th Birthday Setup', src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/4t3h3e4j_A0A29724-C849-425F-B2F0-3B7C709A28A8segment_video_2.MP4' },
  { title: 'Graduation Party - UofC Nursing 2024', src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/r1on7fki_ssstwitter.com_1750132396469.mov' },
  { title: 'Grade 12 Graduation Party', src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/30zsc54z_ssstwitter.com_1765730105244.mov' },
  { title: '2024 Christmas Party for BCA Community Association', src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/q80ayrne_AQMha25yjbPhTp-68qE5izcwpQoXF8qFfjRa2Y4Yh7rdJPxCIzMWfMxjMgH7R9sg_ycuCMu25AVyVPjZfdi1kyem.MP4' },
  { title: 'Various Lighting Setup - Wedding Reception', src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/3wrfkoii_AQONKSk1uEOL_ObHpTudRSquxEEjkOrkeDuWfP7DnIVkZOAqXfSOEBWxBuClkBFOZjT2AgCA7L0-M0RKCKKHpm5Dsf5L8k2NqBPd5r2Q6w.MP4' },
  { title: 'DJ Setup in Action', src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/gk2npzco_AQOSPdKsArrB7qDoSgWwtTkdBj1-2TzMXMGLFB_h68yv4Qt84wbW27F9asvgU65PzMPFZeG7beKnXXkynw6GWb5r.MP4' },
  { title: 'Party Vibes', src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/d9ouwyx4_IMG_1966.mov' },
];

export const SETUP_GALLERY = [
  { src: '/assets/setup-arkadia.jpg', alt: 'Arkadia Grand Ballroom Setup' },
  { src: 'https://customer-assets.emergentagent.com/job_legacy-intact/artifacts/8p5hc3ec_IMG_5997.JPG', alt: 'Ballroom DJ Booth Setup' },
  { src: 'https://customer-assets.emergentagent.com/job_legacy-intact/artifacts/7cdln2iu_IMG_5998.JPG', alt: 'Stage Lighting & Speaker Rig' },
  { src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/vdzim7u1_IMG_5069.JPG', alt: 'DJ Setup 1' },
  { src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/081b2mwb_IMG_5070.JPG', alt: 'DJ Setup 2' },
  { src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/8h04djk2_IMG_4188.JPG', alt: 'DJ Setup 3' },
  { src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/fl4w0uh1_IMG_2615.JPG', alt: 'DJ Setup 4' },
  { src: '/assets/setup-8.jpg', alt: 'DJ Setup 5' },
  { src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/0jrdwup3_IMG_1818.JPG', alt: 'DJ Setup 6' },
  { src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/z212qufz_IMG_0732.JPG', alt: 'DJ Setup 7' },
  { src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/u3zebxyt_IMG_0152.JPG', alt: 'DJ Setup 8' },
  { src: 'https://customer-assets.emergentagent.com/job_c9e04c8b-ed61-4f43-a4fe-cd252be6df80/artifacts/8gyhxjcd_IMG_1618.JPG', alt: 'DJ Setup 9' },
];

export const EVENT_TYPES = [
  'Wedding',
  'Birthday Party',
  'Grad Party',
  'Corporate Event',
  'House Party',
  'Kids Party',
  'Outdoor Party',
  'Club Event',
  'Private Event',
  'Other',
];
