import React, { useState } from 'react';
import { Phone, Clock, MapPin, Instagram, Send, CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { Calendar } from '../components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '../components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { useToast } from '../hooks/use-toast';
import { SITE, EVENT_TYPES } from '../data/content';

const inputClass = 'w-full bg-black/40 border border-[#d4af37]/30 rounded-xl px-4 py-3 text-white placeholder:text-white/35 focus:outline-none focus:border-[#d4af37] focus:ring-2 focus:ring-[#d4af37]/25 transition-colors';

export default function Contact() {
  const { toast } = useToast();
  const [form, setForm] = useState({
    name: '',
    phone: '',
    email: '',
    eventType: '',
    eventDate: null,
    location: '',
    guests: '',
    message: '',
  });

  const onChange = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const onSubmit = (e) => {
    e.preventDefault();
    if (!form.name || !form.phone || !form.eventType || !form.eventDate || !form.location) {
      toast({ title: 'Please complete the required fields', description: 'Name, phone, event type, date, and location are required.' });
      return;
    }
    try {
      const existing = JSON.parse(localStorage.getItem('djs_requests') || '[]');
      existing.push({ ...form, eventDate: form.eventDate?.toISOString?.() || form.eventDate, createdAt: new Date().toISOString() });
      localStorage.setItem('djs_requests', JSON.stringify(existing));
    } catch (err) { /* ignore */ }

    toast({ title: 'Request sent!', description: "Thanks, I'll get back to you within 24 hours." });
    setForm({ name: '', phone: '', email: '', eventType: '', eventDate: null, location: '', guests: '', message: '' });
  };

  const InfoCard = ({ icon: Icon, label, value, href, external }) => {
    const inner = (
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-red-700 flex items-center justify-center text-white shadow-md border border-[#d4af37]/50">
          <Icon size={20} strokeWidth={2.5} />
        </div>
        <div>
          <div className="text-white/55 text-xs uppercase tracking-wider font-semibold">{label}</div>
          <div className="text-white font-bold mt-0.5">{value}</div>
        </div>
      </div>
    );
    const base = 'block rounded-2xl border border-[#d4af37]/25 bg-[#120909] p-6 shadow-md';
    if (href) {
      return (
        <a
          href={href}
          {...(external ? { target: '_blank', rel: 'noreferrer' } : {})}
          className={`${base} hover:border-[#d4af37]/70 hover:shadow-[0_10px_30px_-10px_rgba(212,175,55,0.3)] transition-all`}
        >
          {inner}
        </a>
      );
    }
    return <div className={base}>{inner}</div>;
  };

  return (
    <div>
      <section className="pt-16 pb-12 relative overflow-hidden">
        <div className="pointer-events-none absolute -top-32 left-1/2 -translate-x-1/2 h-96 w-[700px] rounded-full bg-red-700/15 blur-3xl" />
        <div className="max-w-5xl mx-auto px-5 lg:px-8 text-center relative">
          <p className="text-[#f3d273] font-semibold text-xs tracking-[0.25em] uppercase mb-4">Get in Touch</p>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-5">
            Book or <span className="text-[#f3d273]">Request a Quote</span>
          </h1>
          <p className="text-white/65 text-lg max-w-xl mx-auto">
            Ready for your event? Fill out the form below and I'll get back to you within 24 hours.
          </p>
        </div>
      </section>

      <section className="pb-24">
        <div className="max-w-7xl mx-auto px-5 lg:px-8 grid lg:grid-cols-3 gap-6">
          <div className="space-y-5">
            <InfoCard icon={Phone} label="Call or Text" value={SITE.phone} href={SITE.phoneTel} />
            <InfoCard icon={Clock} label="Response Time" value="Within 24 hours" />
            <InfoCard icon={MapPin} label="Service Area" value={SITE.serviceArea} />
            <InfoCard icon={Instagram} label="Follow Me" value={SITE.instagramHandle} href={SITE.instagram} external />
          </div>

          <div className="lg:col-span-2 rounded-2xl border border-[#d4af37]/30 bg-[#120909] shadow-lg p-7 lg:p-9">
            <h2 className="text-white text-2xl font-bold mb-7">Request a Quote</h2>

            <form onSubmit={onSubmit} className="space-y-5">
              <div className="grid md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-white/80 text-sm font-semibold mb-2">Name <span className="text-[#f3d273]">*</span></label>
                  <input className={inputClass} placeholder="Your name" value={form.name} onChange={(e) => onChange('name', e.target.value)} />
                </div>
                <div>
                  <label className="block text-white/80 text-sm font-semibold mb-2">Phone <span className="text-[#f3d273]">*</span></label>
                  <input className={inputClass} placeholder="(xxx) xxx-xxxx" value={form.phone} onChange={(e) => onChange('phone', e.target.value)} />
                </div>
              </div>

              <div>
                <label className="block text-white/80 text-sm font-semibold mb-2">Email</label>
                <input type="email" className={inputClass} placeholder="your@email.com" value={form.email} onChange={(e) => onChange('email', e.target.value)} />
              </div>

              <div className="grid md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-white/80 text-sm font-semibold mb-2">Event Type <span className="text-[#f3d273]">*</span></label>
                  <Select value={form.eventType} onValueChange={(v) => onChange('eventType', v)}>
                    <SelectTrigger className="w-full bg-black/40 border border-[#d4af37]/30 text-white h-12 rounded-xl focus:ring-2 focus:ring-[#d4af37]/25 focus:border-[#d4af37] data-[placeholder]:text-white/35">
                      <SelectValue placeholder="Select event" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#120909] border border-[#d4af37]/30 text-white">
                      {EVENT_TYPES.map((t) => (
                        <SelectItem key={t} value={t} className="focus:bg-red-700/30 focus:text-[#f3d273]">{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="block text-white/80 text-sm font-semibold mb-2">Event Date <span className="text-[#f3d273]">*</span></label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <button
                        type="button"
                        className={`${inputClass} h-12 flex items-center justify-start gap-3 text-left ${!form.eventDate ? 'text-white/35' : 'text-white'}`}
                      >
                        <CalendarIcon size={18} className="text-[#f3d273]" />
                        {form.eventDate ? format(form.eventDate, 'PPP') : 'Pick a date'}
                      </button>
                    </PopoverTrigger>
                    <PopoverContent className="p-0 bg-[#120909] border border-[#d4af37]/30 shadow-xl" align="start">
                      <Calendar
                        mode="single"
                        selected={form.eventDate}
                        onSelect={(d) => onChange('eventDate', d)}
                        initialFocus
                        className="text-white"
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-white/80 text-sm font-semibold mb-2">Location <span className="text-[#f3d273]">*</span></label>
                  <input className={inputClass} placeholder="Venue or city" value={form.location} onChange={(e) => onChange('location', e.target.value)} />
                </div>
                <div>
                  <label className="block text-white/80 text-sm font-semibold mb-2">Estimated Guests</label>
                  <input className={inputClass} placeholder="e.g., 50-100" value={form.guests} onChange={(e) => onChange('guests', e.target.value)} />
                </div>
              </div>

              <div>
                <label className="block text-white/80 text-sm font-semibold mb-2">Message</label>
                <textarea
                  rows={4}
                  className={`${inputClass} resize-none`}
                  placeholder="Tell me about your event..."
                  value={form.message}
                  onChange={(e) => onChange('message', e.target.value)}
                />
              </div>

              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-2 bg-red-700 hover:bg-red-600 text-white font-bold px-7 py-4 rounded-full transition-colors duration-200 shadow-[0_0_30px_rgba(212,175,55,0.3)] border border-[#d4af37]/60"
              >
                <Send size={18} /> Submit Request
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
}
