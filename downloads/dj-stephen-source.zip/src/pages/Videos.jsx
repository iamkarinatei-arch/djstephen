import React from 'react';
import { VIDEOS } from '../data/content';
import VideoCard from '../components/VideoCard';

export default function Videos() {
  return (
    <div>
      <section className="pt-16 pb-12 relative overflow-hidden">
        <div className="pointer-events-none absolute -top-32 left-1/2 -translate-x-1/2 h-96 w-[700px] rounded-full bg-red-700/15 blur-3xl" />
        <div className="max-w-7xl mx-auto px-5 lg:px-8 text-center relative">
          <p className="text-[#f3d273] font-semibold text-xs tracking-[0.25em] uppercase mb-4">Live Footage</p>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-5">
            Recent <span className="text-[#f3d273]">Parties &amp; Events</span>
          </h1>
          <p className="text-white/65 text-lg max-w-2xl mx-auto">
            Highlights from weddings, grad parties, corporate events, and club nights I've worked.
          </p>
        </div>
      </section>

      <section className="pb-24">
        <div className="max-w-6xl mx-auto px-5 lg:px-8">
          <div className="grid sm:grid-cols-2 gap-8">
            {VIDEOS.map((v) => (
              <VideoCard key={v.src} title={v.title} src={v.src} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
