import React, { useState } from 'react';
import { X } from 'lucide-react';
import { SETUP_GALLERY } from '../data/content';

export default function Setup() {
  const [lightbox, setLightbox] = useState(null);

  return (
    <div>
      <section className="pt-16 pb-12 relative overflow-hidden">
        <div className="pointer-events-none absolute -top-32 left-1/2 -translate-x-1/2 h-96 w-[700px] rounded-full bg-red-700/15 blur-3xl" />
        <div className="max-w-7xl mx-auto px-5 lg:px-8 text-center relative">
          <p className="text-[#f3d273] font-semibold text-xs tracking-[0.25em] uppercase mb-4">Gallery</p>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-5">
            Setup <span className="text-[#f3d273]">&amp; Pictures</span>
          </h1>
          <p className="text-white/65 text-lg max-w-2xl mx-auto">
            A look at my professional setups, lighting designs, and atmospheres from real events across Calgary.
          </p>
        </div>
      </section>

      <section className="pb-24">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {SETUP_GALLERY.map((img, idx) => (
              <button
                key={img.src}
                onClick={() => setLightbox(img)}
                className="group relative aspect-[4/3] rounded-2xl overflow-hidden border border-[#d4af37]/25 hover:border-[#d4af37]/70 shadow-md hover:shadow-[0_15px_40px_-10px_rgba(212,175,55,0.3)] transition-all duration-300 text-left bg-black"
              >
                <img
                  src={img.src}
                  alt={img.alt}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60 group-hover:opacity-90 transition-opacity" />
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-white bg-red-700 px-3 py-1.5 rounded-full border border-[#d4af37]/50 shadow-md">
                    Setup {idx + 1}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {lightbox && (
        <div
          className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setLightbox(null)}
        >
          <button
            className="absolute top-5 right-5 bg-red-700 hover:bg-red-600 text-white p-3 rounded-full border border-[#d4af37]/50 shadow-xl transition-colors"
            onClick={() => setLightbox(null)}
          >
            <X size={22} />
          </button>
          <img
            src={lightbox.src}
            alt={lightbox.alt}
            className="max-w-full max-h-[90vh] object-contain rounded-xl shadow-2xl ring-1 ring-[#d4af37]/40"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}
