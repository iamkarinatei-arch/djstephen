import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Heart, Cake, GraduationCap, Building2, Music, PartyPopper, Star } from 'lucide-react';
import { HERO, SPECIALTIES } from '../data/content';

const ICONS = { Heart, Cake, GraduationCap, Building2, Music, PartyPopper };

export default function Home() {
  return (
    <div className="relative">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute -top-32 left-1/4 h-96 w-96 rounded-full bg-red-700/20 blur-3xl" />
        <div className="pointer-events-none absolute top-20 right-1/4 h-96 w-96 rounded-full bg-[#d4af37]/15 blur-3xl" />

        <div className="max-w-7xl mx-auto px-5 lg:px-8 py-16 lg:py-24 grid lg:grid-cols-2 gap-12 lg:gap-20 items-center relative">
          <div className="relative">
            <div className="absolute -inset-3 bg-gradient-to-tr from-red-700/40 to-[#d4af37]/30 rounded-3xl blur-xl opacity-70" />
            <div className="relative rounded-3xl overflow-hidden shadow-2xl ring-2 ring-[#d4af37]/40">
              <img
                src={HERO.image}
                alt="DJ Stephen"
                className="w-full h-[560px] object-cover"
              />

              <div className="absolute top-5 left-5 flex items-center gap-2 bg-black/70 backdrop-blur-md border border-[#d4af37]/50 rounded-full px-3 py-1.5">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
                </span>
                <span className="text-white text-xs font-bold">Available for bookings</span>
              </div>

              <div className="absolute bottom-5 right-5 flex items-center gap-2 bg-black/70 backdrop-blur-md border border-[#d4af37]/50 rounded-full px-4 py-2">
                <Star size={14} className="text-[#f3d273] fill-[#f3d273]" />
                <span className="text-white text-sm font-bold">5.0</span>
                <span className="text-white/60 text-xs">Google rated</span>
              </div>
            </div>
          </div>

          <div>
            <p className="text-[#f3d273] font-semibold text-xs tracking-[0.25em] uppercase mb-5">
              {HERO.kicker}
            </p>
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.05] mb-8 text-white">
              {HERO.titleStart}
              <span className="text-[#f3d273]">{HERO.titleAccent}</span>
            </h1>
            <p className="text-white/70 text-lg leading-relaxed mb-6">{HERO.p1}</p>
            <p className="text-white/70 text-lg leading-relaxed mb-10">{HERO.p2}</p>

            <div className="flex flex-wrap gap-4">
              <Link
                to="/packages"
                className="inline-flex items-center gap-2 bg-red-700 hover:bg-red-600 text-white font-semibold px-7 py-3.5 rounded-full transition-colors duration-200 shadow-[0_0_25px_rgba(212,175,55,0.3)] border border-[#d4af37]/60"
              >
                View Packages <ArrowRight size={18} />
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 bg-transparent border-2 border-[#d4af37] text-[#f3d273] hover:bg-[#d4af37]/10 font-semibold px-7 py-3.5 rounded-full transition-colors duration-200"
              >
                Get in Touch
              </Link>
            </div>

            <div className="mt-12 grid grid-cols-3 gap-6 max-w-md">
              <div>
                <div className="text-3xl font-bold text-[#f3d273]">200+</div>
                <div className="text-white/55 text-xs mt-1 uppercase tracking-wider font-semibold">Events</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-[#f3d273]">5.0★</div>
                <div className="text-white/55 text-xs mt-1 uppercase tracking-wider font-semibold">Rating</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-[#f3d273]">24h</div>
                <div className="text-white/55 text-xs mt-1 uppercase tracking-wider font-semibold">Response</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Specialties */}
      <section className="relative py-20 lg:py-28 bg-black/40 border-y border-[#d4af37]/20">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="text-center mb-16">
            <p className="text-[#f3d273] font-semibold text-xs tracking-[0.25em] uppercase mb-4">What I Do</p>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white">
              Events I <span className="text-[#f3d273]">Specialize</span> In
            </h2>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {SPECIALTIES.map((s) => {
              const Icon = ICONS[s.icon];
              return (
                <div
                  key={s.title}
                  className="group relative rounded-2xl border border-[#d4af37]/25 hover:border-[#d4af37]/70 bg-[#120909] p-7 shadow-md hover:shadow-[0_15px_40px_-10px_rgba(212,175,55,0.25)] transition-all duration-300"
                >
                  <div className="w-14 h-14 rounded-2xl bg-red-700/20 border border-[#d4af37]/40 flex items-center justify-center mb-6 group-hover:bg-red-700/30 transition-colors">
                    <Icon className="text-[#f3d273]" size={26} strokeWidth={2.25} />
                  </div>
                  <h3 className="text-white text-xl font-bold mb-2">{s.title}</h3>
                  <p className="text-white/55 text-sm">{s.desc}</p>
                </div>
              );
            })}
          </div>

          <div className="text-center mt-14">
            <Link
              to="/packages"
              className="inline-flex items-center gap-2 bg-red-700 hover:bg-red-600 text-white font-semibold px-7 py-3.5 rounded-full transition-colors duration-200 shadow-[0_0_25px_rgba(212,175,55,0.3)] border border-[#d4af37]/60"
            >
              See My Packages &amp; Pricing <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* Bottom CTA */}
      <section className="relative py-20">
        <div className="max-w-5xl mx-auto px-5 lg:px-8">
          <div className="relative rounded-3xl overflow-hidden p-10 md:p-14 text-center bg-gradient-to-br from-red-800 via-red-700 to-[#7a1414] border-2 border-[#d4af37]/50 shadow-[0_30px_60px_-20px_rgba(212,175,55,0.35)]">
            <div className="pointer-events-none absolute -top-20 right-1/4 h-72 w-72 rounded-full bg-[#d4af37]/30 blur-3xl" />
            <h3 className="relative text-3xl md:text-5xl font-bold text-white mb-4">
              Ready to <span className="text-[#f3d273]">light up</span> your event?
            </h3>
            <p className="relative text-white/85 text-lg mb-8 max-w-xl mx-auto">
              Let's chat about your next celebration. I respond within 24 hours.
            </p>
            <div className="relative flex flex-wrap gap-4 justify-center">
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 bg-[#d4af37] hover:bg-[#e6c046] text-black font-bold px-7 py-3.5 rounded-full transition-colors shadow-md"
              >
                Request a Quote <ArrowRight size={18} />
              </Link>
              <Link
                to="/videos"
                className="inline-flex items-center gap-2 border-2 border-white text-white hover:bg-white/10 font-bold px-7 py-3.5 rounded-full transition-colors"
              >
                Watch Videos
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
