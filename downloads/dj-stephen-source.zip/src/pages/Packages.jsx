import React from 'react';
import { Link } from 'react-router-dom';
import { Check, Sparkles, Crown } from 'lucide-react';
import { PACKAGES } from '../data/content';

function PackageCard({ pkg }) {
  const isPopular = pkg.accent === 'cyan';
  const isCustom = pkg.isCustom;

  let cardClass = 'border border-[#d4af37]/25 hover:border-[#d4af37]/60 shadow-md';
  let btnClass = 'bg-transparent border-2 border-[#d4af37] text-[#f3d273] hover:bg-[#d4af37]/10';

  if (isPopular) {
    cardClass = 'border-2 border-[#d4af37] shadow-[0_0_40px_-5px_rgba(212,175,55,0.45)] bg-gradient-to-b from-red-900/20 to-[#120909]';
    btnClass = 'bg-[#d4af37] hover:bg-[#e6c046] text-black shadow-md';
  }

  if (isCustom) {
    cardClass = 'border border-red-700/60 shadow-md hover:shadow-[0_0_30px_-5px_rgba(185,28,28,0.4)]';
    btnClass = 'bg-red-700 hover:bg-red-600 text-white border border-[#d4af37]/50';
  }

  return (
    <div className={`relative rounded-2xl bg-[#120909] p-7 flex flex-col transition-all ${cardClass}`}>
      {pkg.badge && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
          <span className={`inline-flex items-center gap-1.5 px-4 py-1 rounded-full text-xs font-bold tracking-wide shadow-md ${
            isPopular ? 'bg-[#d4af37] text-black' : 'bg-red-700 text-white border border-[#d4af37]/50'
          }`}>
            {pkg.badgeStyle === 'cyan' && <Sparkles size={12} fill="currentColor" />}
            {pkg.badge}
          </span>
        </div>
      )}
      {isCustom && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
          <span className="inline-flex items-center gap-1.5 px-4 py-1 rounded-full text-xs font-bold tracking-wide bg-[#d4af37] text-black shadow-md">
            <Crown size={12} fill="currentColor" /> Premium
          </span>
        </div>
      )}

      <h3 className="text-white text-xl font-bold text-center mt-2">{pkg.name}</h3>
      <p className="text-white/55 text-sm text-center mt-2 min-h-[42px]">{pkg.tagline}</p>

      <div className="text-center my-5">
        {isCustom ? (
          <span className="text-4xl font-bold text-[#f3d273]">{pkg.price}</span>
        ) : (
          <>
            <span className="text-4xl font-bold text-[#f3d273]">{pkg.price}</span>
            <span className="text-white/55 text-sm ml-1">{pkg.priceNote}</span>
          </>
        )}
      </div>

      <ul className="space-y-3 mb-7 flex-1">
        {pkg.features.map((f) => (
          <li key={f} className="flex items-start gap-2.5 text-white/80 text-sm">
            <Check size={16} className="text-[#f3d273] mt-0.5 flex-shrink-0" strokeWidth={2.75} />
            <span>{f}</span>
          </li>
        ))}
      </ul>

      <Link
        to="/contact"
        className={`block text-center font-semibold px-6 py-3 rounded-full transition-colors duration-200 ${btnClass}`}
      >
        Book Now
      </Link>
    </div>
  );
}

export default function Packages() {
  return (
    <div>
      <section className="pt-16 pb-14 relative overflow-hidden">
        <div className="pointer-events-none absolute -top-32 left-1/2 -translate-x-1/2 h-96 w-[700px] rounded-full bg-red-700/15 blur-3xl" />
        <div className="max-w-7xl mx-auto px-5 lg:px-8 text-center relative">
          <p className="text-[#f3d273] font-semibold text-xs tracking-[0.25em] uppercase mb-4">Pricing</p>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-5">
            Special Offers &amp; <span className="text-[#f3d273]">Packages</span>
          </h1>
          <p className="text-white/65 text-lg max-w-2xl mx-auto">
            Quality DJ services at competitive prices. Choose a package that fits your event.
          </p>
        </div>
      </section>

      <section className="pb-24">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
            {PACKAGES.map((p) => (
              <PackageCard key={p.name} pkg={p} />
            ))}
          </div>

          <div className="mt-16 max-w-3xl mx-auto text-center">
            <div className="rounded-2xl border border-[#d4af37]/30 bg-[#120909] shadow-md p-8">
              <h3 className="text-white text-xl font-bold mb-2">Need something custom?</h3>
              <p className="text-white/65 mb-6">
                Every event is unique. Reach out and I'll tailor a package to your exact needs and budget.
              </p>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 bg-red-700 hover:bg-red-600 text-white font-semibold px-7 py-3.5 rounded-full transition-colors shadow-[0_0_25px_rgba(212,175,55,0.25)] border border-[#d4af37]/60"
              >
                Request a Custom Quote
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
