import React, { useRef, useState } from 'react';
import { Play, Pause, Volume2, VolumeX, ExternalLink, Maximize2 } from 'lucide-react';

export default function VideoCard({ title, src }) {
  const ref = useRef(null);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(true);
  const [error, setError] = useState(false);

  const toggle = (e) => {
    e.stopPropagation();
    const v = ref.current;
    if (!v) return;
    if (error) {
      window.open(src, '_blank', 'noreferrer');
      return;
    }
    if (v.paused) {
      const p = v.play();
      if (p && p.catch) {
        p.then(() => setPlaying(true)).catch(() => {
          setError(true);
          window.open(src, '_blank', 'noreferrer');
        });
      } else {
        setPlaying(true);
      }
    } else {
      v.pause();
      setPlaying(false);
    }
  };

  const toggleMute = (e) => {
    e.stopPropagation();
    const v = ref.current;
    if (!v) return;
    v.muted = !v.muted;
    setMuted(v.muted);
  };

  const enterFullscreen = (e) => {
    e.stopPropagation();
    const v = ref.current;
    if (!v) return;
    // Try standard, webkit (Safari/iOS), and ms (older Edge) variants
    if (v.requestFullscreen) {
      v.requestFullscreen();
    } else if (v.webkitEnterFullscreen) {
      // iOS Safari
      v.webkitEnterFullscreen();
    } else if (v.webkitRequestFullscreen) {
      v.webkitRequestFullscreen();
    } else if (v.msRequestFullscreen) {
      v.msRequestFullscreen();
    }
  };

  return (
    <div
      onClick={toggle}
      className="group relative rounded-2xl overflow-hidden bg-black border border-[#d4af37]/25 hover:border-[#d4af37]/70 shadow-md cursor-pointer aspect-video transition-all duration-300"
    >
      <video
        ref={ref}
        src={src}
        muted
        playsInline
        preload="metadata"
        className="absolute inset-0 w-full h-full object-cover"
        onEnded={() => setPlaying(false)}
      />

      <div className={`absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/20 transition-opacity duration-300 ${playing ? 'opacity-40' : 'opacity-95'}`} />

      {!error && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className={`bg-red-700 text-white rounded-full p-5 shadow-[0_0_25px_rgba(212,175,55,0.5)] border-2 border-[#d4af37] transform transition-all duration-300 ${playing ? 'opacity-0 scale-75 group-hover:opacity-100 group-hover:scale-100' : 'opacity-100 scale-100'}`}>
            {playing ? <Pause size={28} fill="currentColor" /> : <Play size={28} fill="currentColor" className="ml-1" />}
          </div>
        </div>
      )}

      {error && (
        <a
          href={src}
          target="_blank"
          rel="noreferrer"
          onClick={(e) => e.stopPropagation()}
          className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-white"
        >
          <div className="bg-red-700 text-white rounded-full p-4 shadow-lg border-2 border-[#d4af37]">
            <ExternalLink size={24} />
          </div>
          <span className="text-xs text-white/80 px-3 text-center">Open video</span>
        </a>
      )}

      {/* Top-right action buttons */}
      <div className="absolute top-3 right-3 flex items-center gap-2 z-10">
        {playing && (
          <button
            onClick={toggleMute}
            className="bg-black/70 hover:bg-black/90 text-white p-2 rounded-full backdrop-blur transition-colors border border-[#d4af37]/40"
            aria-label="Toggle sound"
            title="Mute / unmute"
          >
            {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
          </button>
        )}
        <button
          onClick={enterFullscreen}
          className="bg-black/70 hover:bg-black/90 text-white p-2 rounded-full backdrop-blur transition-colors border border-[#d4af37]/40 opacity-0 group-hover:opacity-100"
          aria-label="Fullscreen"
          title="Play fullscreen"
        >
          <Maximize2 size={16} />
        </button>
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-5 text-white text-base md:text-lg font-bold z-10 pointer-events-none drop-shadow-lg">
        {title}
      </div>
    </div>
  );
}
