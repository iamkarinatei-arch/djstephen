import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { Phone, Menu, X } from 'lucide-react';
import { SITE } from '../data/content';

const navItems = [
  { to: '/', label: 'HOME' },
  { to: '/setup', label: 'SETUP & PICTURES' },
  { to: '/videos', label: 'VIDEOS' },
  { to: '/packages', label: 'PACKAGES' },
  { to: '/contact', label: 'CONTACT' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 backdrop-blur-md bg-[#0a0606]/90 border-b border-[#d4af37]/30">
      <div className="max-w-7xl mx-auto px-5 lg:px-8 h-20 flex items-center justify-between gap-4">
        <Link to="/" className="flex items-center gap-3 group flex-shrink-0">
          <img src={SITE.logo} alt="DJ Stephen Logo" className="h-9 w-9 object-contain" />
          <span className="text-white font-bold text-lg tracking-wide hidden sm:inline">{SITE.brand}</span>
        </Link>

        <nav className="hidden lg:flex items-center gap-1 rounded-full border border-[#d4af37]/40 bg-black/40 px-2 py-1.5">
          {navItems.map((it) => (
            <NavLink
              key={it.to}
              to={it.to}
              end={it.to === '/'}
              className={({ isActive }) =>
                `px-4 py-2 rounded-full text-[12px] font-semibold tracking-wider transition-colors duration-200 ${
                  isActive
                    ? 'text-white bg-red-700'
                    : 'text-white/75 hover:text-[#f3d273]'
                }`
              }
            >
              {it.label}
            </NavLink>
          ))}
        </nav>

        <a
          href={SITE.phoneTel}
          className="hidden md:inline-flex items-center gap-2 bg-red-700 hover:bg-red-600 text-white font-semibold px-5 py-3 rounded-full transition-colors duration-200 shadow-[0_0_20px_rgba(212,175,55,0.25)] border border-[#d4af37]/50 text-sm"
        >
          <Phone size={16} strokeWidth={2.5} />
          {SITE.phone}
        </a>

        <button
          className="lg:hidden text-white p-2"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden border-t border-[#d4af37]/20 bg-[#0a0606]">
          <div className="px-5 py-4 flex flex-col gap-2">
            {navItems.map((it) => (
              <NavLink
                key={it.to}
                to={it.to}
                end={it.to === '/'}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  `px-4 py-3 rounded-lg text-sm font-semibold tracking-wider ${
                    isActive
                      ? 'text-white bg-red-700'
                      : 'text-white/80 hover:bg-white/5'
                  }`
                }
              >
                {it.label}
              </NavLink>
            ))}
            <a
              href={SITE.phoneTel}
              className="mt-2 inline-flex items-center justify-center gap-2 bg-red-700 text-white font-semibold px-5 py-3 rounded-full border border-[#d4af37]/50"
            >
              <Phone size={16} strokeWidth={2.5} />
              {SITE.phone}
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
