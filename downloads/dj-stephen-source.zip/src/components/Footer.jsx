import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, MapPin, Instagram } from 'lucide-react';
import { SITE } from '../data/content';

export default function Footer() {
  return (
    <footer className="bg-black border-t border-[#d4af37]/30">
      <div className="max-w-7xl mx-auto px-5 lg:px-8 py-16">
        <div className="grid md:grid-cols-3 gap-12">
          <div>
            <img src={SITE.logo} alt="DJ Stephen" className="h-12 w-12 object-contain mb-4" />
            <h3 className="text-white text-xl font-bold mb-3">{SITE.brand}</h3>
            <p className="text-white/60 text-sm leading-relaxed max-w-xs">{SITE.tagline}</p>
          </div>

          <div>
            <h4 className="text-[#f3d273] font-bold mb-5">Quick Links</h4>
            <ul className="space-y-3">
              <li><Link to="/" className="text-white/70 hover:text-[#f3d273] transition-colors text-sm font-medium">Home</Link></li>
              <li><Link to="/setup" className="text-white/70 hover:text-[#f3d273] transition-colors text-sm font-medium">Setup & Pictures</Link></li>
              <li><Link to="/videos" className="text-white/70 hover:text-[#f3d273] transition-colors text-sm font-medium">Videos</Link></li>
              <li><Link to="/packages" className="text-white/70 hover:text-[#f3d273] transition-colors text-sm font-medium">Packages</Link></li>
              <li><Link to="/contact" className="text-white/70 hover:text-[#f3d273] transition-colors text-sm font-medium">Contact</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-[#f3d273] font-bold mb-5">Contact</h4>
            <ul className="space-y-3">
              <li>
                <a href={SITE.phoneTel} className="flex items-center gap-3 text-white/70 hover:text-[#f3d273] transition-colors text-sm font-medium">
                  <span className="w-8 h-8 rounded-full bg-red-700 text-white flex items-center justify-center border border-[#d4af37]/50"><Phone size={14} /></span>
                  {SITE.phone}
                </a>
              </li>
              <li className="flex items-center gap-3 text-white/70 text-sm font-medium">
                <span className="w-8 h-8 rounded-full bg-red-700 text-white flex items-center justify-center border border-[#d4af37]/50"><MapPin size={14} /></span>
                {SITE.location}
              </li>
              <li>
                <a href={SITE.instagram} target="_blank" rel="noreferrer" className="flex items-center gap-3 text-white/70 hover:text-[#f3d273] transition-colors text-sm font-medium">
                  <span className="w-8 h-8 rounded-full bg-red-700 text-white flex items-center justify-center border border-[#d4af37]/50"><Instagram size={14} /></span>
                  {SITE.instagramHandle}
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-[#d4af37]/20 text-center text-white/50 text-sm">
          © {new Date().getFullYear()} {SITE.brand}. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
