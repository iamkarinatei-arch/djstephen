import React from 'react';
import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Setup from './pages/Setup';
import Videos from './pages/Videos';
import Packages from './pages/Packages';
import Contact from './pages/Contact';
import { Toaster } from './components/ui/toaster';
import ScrollToTop from './components/ScrollToTop';

function App() {
  return (
    <div className="min-h-screen text-white bg-[#0a0606]">
      <BrowserRouter>
        <ScrollToTop />
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/setup" element={<Setup />} />
            <Route path="/videos" element={<Videos />} />
            <Route path="/packages" element={<Packages />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </main>
        <Footer />
      </BrowserRouter>
      <Toaster />
    </div>
  );
}

export default App;
